ESX = exports['es_extended']:getSharedObject()

local coffeeMachines = {
    vector3(-586.8249, -1061.9409, 23.3547),
}

for _, coords in ipairs(coffeeMachines) do
    exports.ox_target:addBoxZone({
        coords = coords,
        size = vector3(1.0, 1.0, 1.5),
        options = {
            {
                event = 'coffee:grindBeans',
                icon = 'fas fa-coffee',
                label = 'Zmiel ziarna kawy'
            },
            {
                event = 'coffee:makeCoffee',
                icon = 'fas fa-mug-hot',
                label = 'Zrób kawę'
            }
        }
    })
end

RegisterNetEvent('coffee:grindBeans', function()
    print("Rozpoczynanie minigierki...")
    exports["memorygame"]:thermiteminigame(5, 3, 3, 5,
        function() -- success
            print("Minigierka zakończona sukcesem!")
            TriggerServerEvent('coffee:giveItem', 'bulka_kawka')
            exports["DP_notify"]:Notify('success', 'Powiadomienie', "Udało ci się!")

        end,
        function() -- failure
            print("Minigierka nieudana.")
            exports["DP_notify"]:Notify('failure', 'Powiadomienie', "No, niestety, coś nie pykło.")

        end
    )
end)



RegisterNetEvent('coffee:makeCoffee', function()
    TriggerServerEvent('coffee:processCoffee')
    exports["DP_notify"]:Notify('success', 'Powiadomienie', "Zrobiłeś pyszną kawkę!")
end)