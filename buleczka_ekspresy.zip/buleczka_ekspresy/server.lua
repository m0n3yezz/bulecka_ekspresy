ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('coffee:giveItem', function(item)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        xPlayer.addInventoryItem(item, 1)
        TriggerClientEvent('ox_inventory:notify', src, item, 1)
    end
end)

RegisterNetEvent('coffee:processCoffee', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        local item = xPlayer.getInventoryItem('bulka_kawka')
        if item and item.count >= 3 then
            xPlayer.removeInventoryItem('bulka_kawka', 3)
            xPlayer.addInventoryItem('bulka_donekawka', 1)
            TriggerClientEvent('ox_inventory:notify', src, 'bulka_donekawka', 1)
        end
    end
end)
